<?php
/**
 * RETIRADO de la raíz web el 2026-10-17.
 *
 * Era un tercer punto de entrada, duplicado del de la raíz y del de public/, y no
 * funcionaba: bajo el .htaccess de la raíz no se sirve (todo se reescribe a public/),
 * y cuando se alcanzaba devolvía HTTP 200 con «Uncaught ArgumentCountError» en
 * config/routes.php:44 y la traza a la vista. Nada lo referenciaba.
 * Deuda 10 de la constitución.
 *
 * Se conserva por historial, no para usarlo. Sus rutas son relativas
 * (__DIR__ . '/../config/...'), así que después del traslado no se ejecuta.
 * El punto de entrada de verdad es public/index.php; para instalar, docs/INSTALL.md.
 */
// ═══════════════════════════════════════════════════════════════════
// PUNTO DE ENTRADA DE LA APLICACIÓN
// ═══════════════════════════════════════════════════════════════════

declare(strict_types=1);

// ═══════════════════════════════════════════════════════════════════
// 1. CARGAR CONSTANTES Y CONFIGURACIÓN
// ═══════════════════════════════════════════════════════════════════
require __DIR__ . '/../config/paths.php';

// ═══════════════════════════════════════════════════════════════════
// 2. AUTOLOADER PSR-4 CON MANEJO DE ERRORES
// ═══════════════════════════════════════════════════════════════════
spl_autoload_register(function (string $class) {
    // Solo procesar clases del namespace App\
    if (!str_starts_with($class, 'App\\')) {
        return;
    }

    // Convertir namespace a ruta de archivo
    $relativeClass = substr($class, 4); // Quitar 'App\'
    $path = APP_PATH . '/' . str_replace('\\', '/', $relativeClass) . '.php';

    if (is_file($path)) {
        require_once $path;
        return;
    }

    // Si no se encuentra, registrar error (solo en modo debug)
    if (file_exists(CONFIG_PATH . '/config.php')) {
        $cfg = require CONFIG_PATH . '/config.php';
        if ($cfg['debug'] ?? false) {
            error_log("[Autoloader] Clase no encontrada: $class (ruta: $path)");
        }
    }
});

// ═══════════════════════════════════════════════════════════════════
// 3. CARGAR HELPERS GLOBALES
// ═══════════════════════════════════════════════════════════════════
if (is_file(APP_PATH . '/Helpers/functions.php')) {
    require_once APP_PATH . '/Helpers/functions.php';
} else {
    die('Error: No se encontró el archivo de helpers en ' . APP_PATH . '/Helpers/functions.php');
}

// ═══════════════════════════════════════════════════════════════════
// 4. CARGAR CONFIGURACIÓN GENERAL
// ═══════════════════════════════════════════════════════════════════
if (!is_file(CONFIG_PATH . '/config.php')) {
    die('Error: No se encontró el archivo de configuración en ' . CONFIG_PATH . '/config.php');
}

$cfg = require CONFIG_PATH . '/config.php';
date_default_timezone_set($cfg['timezone'] ?? 'UTC');

// Configurar manejo de errores
if ($cfg['debug'] ?? false) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}

// ═══════════════════════════════════════════════════════════════════
// 5. VERIFICAR CONEXIÓN A BD
// ═══════════════════════════════════════════════════════════════════
if (!is_file(CONFIG_PATH . '/database.php')) {
    // Redirigir al instalador si no hay configuración de BD
    if (basename($_SERVER['REQUEST_URI'] ?? '') !== 'install.php') {
        header('Location: install.php');
        exit;
    }
}

// ═══════════════════════════════════════════════════════════════════
// 6. INICIALIZAR SESIÓN Y BOOTSTRAP
// ═══════════════════════════════════════════════════════════════════
try {
    App\Core\Session::start();
    App\Core\App::boot();
} catch (Throwable $e) {
    if ($cfg['debug'] ?? false) {
        die('Error al inicializar la aplicación: ' . $e->getMessage());
    } else {
        die('Error interno del servidor');
    }
}

// ═══════════════════════════════════════════════════════════════════
// 7. INICIALIZAR ROUTER Y REQUEST
// ═══════════════════════════════════════════════════════════════════
try {
    $router = new App\Core\Router();
    $req = new App\Core\Request();
} catch (Throwable $e) {
    if ($cfg['debug'] ?? false) {
        die('Error al inicializar el router: ' . $e->getMessage());
    } else {
        die('Error interno del servidor');
    }
}

// ═══════════════════════════════════════════════════════════════════
// 8. CARGAR RUTAS DESDE ARCHIVO EXTERNO
// ═══════════════════════════════════════════════════════════════════
if (is_file(CONFIG_PATH . '/routes.php')) {
    $routes = require CONFIG_PATH . '/routes.php';
    if (is_callable($routes)) {
        $routes($router);
    }
} else {
    die('Error: No se encontró el archivo de rutas en ' . CONFIG_PATH . '/routes.php');
}

// ═══════════════════════════════════════════════════════════════════
// 9. DISPATCH CON MANEJO DE ERRORES
// ═══════════════════════════════════════════════════════════════════
try {
    $router->dispatch($req);
} catch (Throwable $e) {
    if ($cfg['debug'] ?? false) {
        echo '<h1>Error</h1>';
        echo '<pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
        echo '<pre>' . htmlspecialchars($e->getTraceAsString()) . '</pre>';
    } else {
        http_response_code(500);
        echo '<h1>Error interno del servidor</h1>';
        error_log('[Router] Error: ' . $e->getMessage());
    }
}