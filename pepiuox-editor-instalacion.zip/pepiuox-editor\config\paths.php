<?php
/**
 * Configuración centralizada de Rutas y URLs
 * Evita problemas de inclusión de archivos y generación de enlaces.
 */

// ═══════════════════════════════════════════════════════════════
// 1. RUTAS ABSOLUTAS DEL SISTEMA (Filesystem)
// Usadas para: include, require, file_get_contents, mkdir, etc.
// ═══════════════════════════════════════════════════════════════

// ROOT_PATH apunta a la carpeta raíz del proyecto (donde está la carpeta config/)
define('ROOT_PATH', str_replace('\\', '/', dirname(__DIR__)));

// ✅ Definir rutas base
/**
 * Configuración de rutas del sistema
 */

if (!defined('APP_PATH')) {
    define('APP_PATH', ROOT_PATH . '/app');
}
define('CONFIG_PATH', ROOT_PATH . '/config');
define('PUBLIC_PATH', ROOT_PATH . '/public');
define('PRIVATE_PATH', ROOT_PATH . '/private');
define('VIEWS_PATH', ROOT_PATH . '/views');
define('STORAGE_PATH', ROOT_PATH . '/storage');
define('CACHE_PATH', STORAGE_PATH . '/cache');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('ASSETS_PATH', PUBLIC_PATH . '/assets');
define('VENDOR_PATH', ROOT_PATH . '/vendor');
define('LOGS_PATH', STORAGE_PATH . '/logs');

// ✅ Definir constantes de categorías
if (!defined('FILE_CATEGORIES')) {
    define('FILE_CATEGORIES', ['document', 'image', 'audio', 'video', 'archive', 'other']);
}

// ✅ Definir extensiones permitidas
if (!defined('ALLOWED_EXTENSIONS')) {
    define('ALLOWED_EXTENSIONS', [
        'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg',
        'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
        'txt', 'csv',
        'zip', 'rar', 'tar', 'gz', '7z',
        'mp3', 'wav', 'ogg', 'm4a',
        'mp4', 'mpeg', 'webm', 'mov', 'avi'
    ]);
}

// ═══════════════════════════════════════════════════════════════
// 2. URLS WEB (Navegador)
// Usadas para: <link>, <img>, <script>, Location header, etc.
// ═══════════════════════════════════════════════════════════════

// Detectar protocolo (http o https)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';

// Detectar el subdirectorio base automáticamente.
// Si SCRIPT_NAME es "/public/index.php", dirname será "/public".
// Si SCRIPT_NAME es "/index.php", dirname será "/".
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$basePath = ($scriptDir === '/' || $scriptDir === '\\') ? '' : $scriptDir;

// `/public` es un detalle interno del despliegue: el .htaccess de la raíz
// reescribe las URLs limpias hacia public/. Si se dejara dentro de BASE_URL,
// cada enlace, asset y formulario generado por la aplicación mostraría /public/
// en el navegador. Se recorta para que la URL pública sea la raíz del sitio.
if ($basePath === '/public' || str_ends_with($basePath, '/public')) {
    $basePath = substr($basePath, 0, -strlen('/public'));
}

// URL base de la aplicación (ej: http://localhost:170)
define('BASE_URL', $protocol . $host . $basePath);


if (!defined('BASE_URL')) {
    // Detectar URL base automáticamente
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
    define('BASE_URL', $protocol . $host . $basePath);
}

// URLs específicas de recursos
define('ASSETS_URL', BASE_URL . '/assets');
define('UPLOADS_URL', BASE_URL . '/uploads');

// ═══════════════════════════════════════════════════════════════
// 3. ALIAS DE COMPATIBILIDAD (Para migrar código antiguo fácilmente)
// ═══════════════════════════════════════════════════════════════
define('SITE_URL', BASE_URL);
define('URL_BASE', BASE_URL); 
define('BASE_PATH', $basePath . '/'); // ej: 'public/' o '/'
define('VIEWS', 'views'); // Relativo a ROOT_PATH

// Crear directorios necesarios si no existen
$directories = [
    CACHE_PATH,
    LOGS_PATH,
    UPLOADS_PATH,
    STORAGE_PATH . '/cache/pages',
    STORAGE_PATH . '/cache/data',
];

foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
}
