---
technical_level: technical
project_kind: software
---

# User profile

Goal: Editor/CMS web en PHP 8 y MySQL con panel de administración: páginas, versiones, plantillas, menús, usuarios y roles
